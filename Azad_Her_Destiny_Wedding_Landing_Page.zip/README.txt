AZAD & HER DESTINY — Wedding Landing Page

Files:
- index.html — complete responsive landing page
- wedding-couple.png — wedding background image
- wedding-instrumental.wav — original instrumental background music

Open index.html in a browser. The invitation starts after tapping OPEN INVITATION so the browser can allow background music.
Countdown is set to 19 October 2026, Pakistan Standard Time (UTC+5).
